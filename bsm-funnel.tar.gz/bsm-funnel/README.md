# BSM Funnel — The Buyer Signal Method

## What This Is
A standalone sales funnel for The Buyer Signal Method by Undeniable. This is a separate project from the main Undeniable website. It deploys on Vercel via its own GitHub repo and connects via subdomain (e.g., `go.weareundeniable.com`).

## Tech Stack
- **Framework:** Vite + React + TypeScript
- **Styling:** Tailwind CSS v3 (custom config with Undeniable design tokens)
- **Animations:** Framer Motion (minimal, purposeful — see DESIGN.md)
- **Video:** Wistia embed (lazy loaded)
- **Payments:** Stripe embedded checkout + Vercel serverless functions for upsell charges
- **Deployment:** Vercel

## Funnel Flow
```
/                → Landing page (Buyer Signal Method sales page)
/upsell          → Upsell 1 (Campaign setup — $47 or $97)
/upsell-2        → [Future] Upsell 2 (slot available)
/thank-you       → Thank you page (access + book-a-call CTA)
```

Each page is an independent component. Adding a new upsell = new file + one route line in App.tsx.

## Source of Truth Files
- **COPY.md** — All landing page copy. Components pull text from here verbatim. Do not improvise or rewrite copy.
- **DESIGN.md** — UI design system, color tokens, component patterns, animation rules, performance targets.
- **README.md** — This file. Project context and rules.

## Rules
1. All copy comes from COPY.md. Do not change words in components without updating COPY.md first.
2. All visual decisions follow DESIGN.md. Do not add colors, fonts, or animation patterns not defined there.
3. Mobile-first. Design for phone screens first, then expand for desktop.
4. Performance target: under 2 seconds to first meaningful paint on mobile.
5. No external font files. System font stack only.
6. No images in initial build except the Wistia VSL embed (lazy loaded).
7. Every motion element must serve conversion — if it doesn't help the buyer understand, trust, or act, remove it.
8. When making changes, change only what was requested. Do not modify other sections.

## Project Structure
```
src/
  pages/           → Full page components (LandingPage, Upsell, ThankYou)
  components/
    ui/            → Reusable UI components (Button, Card, FAQ, etc.)
    layout/        → Layout wrappers (FunnelLayout, Section, StickyBar)
    sections/      → Landing page sections (Hero, Problem, Mechanism, etc.)
  assets/          → Static assets if needed
  App.tsx          → Router
  main.tsx         → Entry point
  index.css        → Tailwind directives + global styles
```

## Stripe Integration (Future)
- Landing page: Stripe embedded checkout form appears on page
- Upsell pages: One-click charge via Vercel serverless function using saved payment method
- Serverless functions live in `/api/` directory (Vercel convention)

## Getting Started
```bash
npm install
npm run dev
```
