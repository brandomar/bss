# Undeniable — UI Design System

This document is the visual source of truth for the BSM Funnel. Every design decision follows these specs. Do not add colors, fonts, effects, or animation patterns not defined here.

---

## Design Philosophy

This page must look like someone paid $10,000 for it. The expensive feel comes from:
- **Spacing** — generous padding, nothing cramped, content breathes
- **Typography hierarchy** — dramatic contrast between headline, subhead, body, and muted text
- **Color restraint** — two accent colors deployed with precision, not scattered
- **Subtle depth** — glass morphism, ambient orbs, layered transparency
- **Micro-details** — hairline borders, consistent alignment, friction eliminator text

The aesthetic is: dark, premium, confident, competent. Not flashy, not guru-energy, not template.

---

## Color Palette

```
Background:
  rich-black:        #0a0a0a     (primary background)
  section-alt:       #0f0f0f     (alternating section bg for depth)
  section-alt-2:     #111111     (subtle variation)

Accent — Primary (Violet):
  violet-50:         #F5F3FF
  violet-100:        #EDE9FE
  violet-200:        #DDD6FE
  violet-300:        #C4B5FD
  violet-400:        #A78BFA
  violet-500:        #7C3AED     (primary — CTAs, eyebrow text, highlights)
  violet-600:        #6D28D9
  violet-700:        #5B21B6
  violet-800:        #4C1D95
  violet-900:        #2E1065

Accent — Secondary (Mint):
  mint-500:          #10B981     (success, guarantee, bonus, positive signals)
  mint-400:          #34D399
  mint-600:          #059669

Text:
  white:             #FFFFFF     (headlines)
  gray-300:          #D1D5DB     (subheadlines)
  gray-400:          #9CA3AF     (body text)
  gray-500:          #6B7280     (muted, supporting text, friction eliminators)
```

### Usage Rules
- Violet: CTAs, eyebrow text, phase labels, interactive highlights. Nothing else.
- Mint: Guarantee, bonus badge, success indicators, checkmarks. Nothing else.
- Never use pure white backgrounds. Dark-mode only.
- Alternating section backgrounds (#0a0a0a → #0f0f0f) create subtle depth without hard dividers.

---

## Typography

- **Font:** System font stack — no external font files (performance critical)
  ```css
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
  ```
- **Headlines:** Bold, text-4xl to text-6xl on desktop, text-3xl to text-4xl on mobile, white
- **Subheadlines:** Medium weight, text-lg to text-xl, gray-300
- **Body:** Regular weight, text-base to text-lg, gray-400
- **Eyebrow text:** Uppercase, tracking-widest, text-xs to text-sm, violet-500, font-semibold
- **Friction eliminators:** text-sm, gray-500, below CTAs

### Gradient Text Effect (use sparingly — key headlines only)
```css
background: linear-gradient(135deg, #7C3AED, #A78BFA, #10B981);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
```

---

## Visual Effects

### Glass Morphism Cards
```css
background: rgba(255, 255, 255, 0.03);
backdrop-filter: blur(12px);
border: 1px solid rgba(255, 255, 255, 0.06);
border-radius: 16px;
padding: 32px;
```
Hover state: border opacity increases to 0.12, subtle violet glow shadow.

### Ambient Orbs
Absolutely-positioned gradient blobs that create depth behind content:
```css
/* Violet orb */
background: radial-gradient(circle, rgba(124, 58, 237, 0.12), transparent 70%);
filter: blur(80px);
width: 400px;
height: 400px;
position: absolute;
pointer-events: none;

/* Mint orb (use less frequently) */
background: radial-gradient(circle, rgba(16, 185, 129, 0.06), transparent 70%);
filter: blur(100px);
```
Place 2-3 per major section, positioned asymmetrically. They should be felt more than seen. No animation on these — static depth only.

### Section Transitions
No hard lines or borders between sections. Depth comes from:
- Generous vertical padding (py-20 to py-32)
- Alternating background tones
- Ambient orb placement bridging sections

---

## Components

### CTA Button
```css
background: linear-gradient(135deg, #7C3AED, #6D28D9);
color: white;
font-weight: 700;
padding: 18px 36px;
border-radius: 12px;
font-size: 1.125rem;
box-shadow: 0 0 30px rgba(124, 58, 237, 0.25);
transition: all 0.3s ease;
```
Hover: scale(1.02), glow increases to 0.4 opacity.
Idle: subtle CSS glow pulse (not JS-driven). Breathing animation, 3-second cycle.
```css
@keyframes glow-pulse {
  0%, 100% { box-shadow: 0 0 30px rgba(124, 58, 237, 0.25); }
  50% { box-shadow: 0 0 40px rgba(124, 58, 237, 0.4); }
}
```

### Mechanism Step Cards
Glass morphism card with:
- Step number: eyebrow style, violet
- Step name: large bold white
- Description: gray-400 body
- Subtle left border accent in violet (3px, rounded)
- On mobile: full-width, stacked vertically with connecting visual (thin line or arrow)
- On desktop: 3-column grid

### Deliverable Items
- Phase label: eyebrow style, violet, uppercase
- Deliverable name: bold white, text-lg
- Description: gray-400, after an em dash
- Grouped visually by phase

### FAQ Accordion
- Question: bold white, clickable, text-base to text-lg
- Plus/chevron icon on right, rotates on open (CSS transition)
- Answer: gray-400, revealed with smooth max-height transition
- Subtle border-bottom between items (rgba white, 0.06)

### Testimonial Cards (when available)
- Glass morphism card
- Quote in gray-300, slightly larger text
- Name + niche below in muted text
- Designed to be placed between sections, not in one block

### Sticky Mobile CTA Bar
- Appears after user scrolls past the first CTA button
- Fixed to bottom of viewport
- Same violet gradient background
- CTA text + price
- Slight top shadow for depth
- Auto-hides if user scrolls back to top where original CTA is visible

---

## Animation Rules

### What Gets Motion
- **Scroll-triggered section entrances:** fade up, once, subtle
  ```
  initial: opacity 0, y 30
  animate: opacity 1, y 0
  duration: 0.6s, ease-out
  viewport: once, margin -100px
  ```
- **Staggered children** (cards, list items): 100ms delay between each
- **CTA glow pulse:** CSS-only, 3s breathing cycle
- **Sticky bar entrance:** slide up from bottom, 0.3s
- **FAQ accordion:** smooth height transition, 0.3s
- **Mechanism steps:** staggered entrance to reinforce progression

### What Does NOT Get Motion
- No particle backgrounds (performance cost, competes with copy)
- No parallax scrolling (disorienting on mobile)
- No animated counters or number tickers
- No hover animations on body text
- No looping animations (nothing moves while reading)
- No decorative motion that doesn't serve conversion

### The Rule
Every animation must serve one of three purposes:
1. Help the buyer understand the system
2. Build trust
3. Draw attention to the CTA

If it doesn't do one of these, it doesn't ship.

---

## Layout

- **Max content width:** max-w-3xl for text, max-w-5xl for card grids
- **Section padding:** py-20 to py-32 (generous — this is what makes it look expensive)
- **Horizontal padding:** px-6 on mobile, px-8 on desktop
- **Card grids:** 1 column mobile, 3 columns desktop
- **All content centered** by default (mx-auto, text-center for headlines)
- **Mobile-first:** every layout decision starts with phone screen, then expands

---

## Performance Targets

- **First meaningful paint:** under 2 seconds on mobile
- **No external font files** — system stack loads instantly
- **No images** in initial build (VSL is the only heavy asset, lazy loaded)
- **Framer Motion** — import only specific functions used, not the full library
- **CSS animations** where possible instead of JS-driven ones
- **Wistia embed** — lazy load, don't block page render

---

## Audience Context (Informs Design Choices)

**Belief: HELPLESS** — They need a clear PROCESS shown visually. The 3-step mechanism should be visually prominent and easy to follow. Professional, competent aesthetic.

**Belief: RESOURCELESS** — The SYSTEM is the hero. Design should make the product feel like the complete answer. Deliverables section feels like machine components, not a course curriculum.

**Belief: IN-TIME** — Speed callouts ("under an hour", "72 hours") get visual emphasis. Page is scannable, not a long commitment to read.

**Authority: SELF-TO-SELF** — Bold, confident design. No weak or apologetic elements. CTAs are commands.

**Three Reader Types:**
1. Full readers: complete story top to bottom
2. Skimmers: headlines alone tell the full story
3. Scrollers: bottom third (price, guarantee, FAQ, final CTA) stands alone as its own pitch

---

## What This Page Must NEVER Look Like
- A Kajabi/Teachable course landing page
- A GHL funnel template
- A generic SaaS marketing page with stock illustrations
- Anything with a light/white background
- Anything with more than two accent colors
- Anything that prioritizes decoration over conversion
