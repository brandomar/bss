import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { LandingPage } from './pages/LandingPage'
import { UpsellPage } from './pages/UpsellPage'
import { ThankYouPage } from './pages/ThankYouPage'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/upsell" element={<UpsellPage />} />
        {/* Future upsells: */}
        {/* <Route path="/upsell-2" element={<UpsellTwoPage />} /> */}
        <Route path="/thank-you" element={<ThankYouPage />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
