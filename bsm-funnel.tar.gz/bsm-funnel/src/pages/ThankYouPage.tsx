import { Section } from '../components/layout/Section'
import { CTAButton } from '../components/ui/CTAButton'

const steps = [
  { number: '1', text: 'Check your email for access.' },
  { number: '2', text: 'Watch the walkthrough video first.' },
  { number: '3', text: 'Run the Gold Mine and start capturing buyer language today.' },
]

export function ThankYouPage() {
  return (
    <Section
      orbs={[
        { color: 'violet', position: 'top-[-10%] right-[-10%]', size: 'w-[450px] h-[450px]' },
        { color: 'mint', position: 'bottom-[-10%] left-[-5%]', size: 'w-[300px] h-[300px]' },
      ]}
      className="min-h-screen flex items-center"
    >
      <div className="text-center">
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-12">
          You're In
        </h1>

        <div className="max-w-lg mx-auto space-y-6 mb-14">
          {steps.map((step) => (
            <div key={step.number} className="glass-card p-6 flex items-start gap-4 text-left">
              <span className="flex-shrink-0 w-8 h-8 rounded-full bg-rich-violet-500/20 flex items-center justify-center text-rich-violet-400 font-bold text-sm">
                {step.number}
              </span>
              <p className="text-gray-300 text-base md:text-lg">
                {step.text}
              </p>
            </div>
          ))}
        </div>

        {/* Book a call CTA */}
        <div className="glass-card p-8 md:p-10 max-w-lg mx-auto">
          <p className="text-gray-400 text-base mb-6">
            Want us to implement this for you?
          </p>
          <CTAButton
            text="Book Your Free Strategy Call"
            href="#book-call"
          />
        </div>
      </div>
    </Section>
  )
}
