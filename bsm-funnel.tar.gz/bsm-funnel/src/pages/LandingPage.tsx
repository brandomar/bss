import { HeroSection } from '../components/sections/HeroSection'
import { ProblemSection } from '../components/sections/ProblemSection'
import { MechanismSection } from '../components/sections/MechanismSection'
import { WhoSection } from '../components/sections/WhoSection'
import { WhatsInsideSection } from '../components/sections/WhatsInsideSection'
import { SocialProofSection } from '../components/sections/SocialProofSection'
import { PriceSection } from '../components/sections/PriceSection'
import { GuaranteeSection } from '../components/sections/GuaranteeSection'
import { FAQSection } from '../components/sections/FAQSection'
import { FinalCTASection } from '../components/sections/FinalCTASection'
import { StickyBar } from '../components/layout/StickyBar'

export function LandingPage() {
  return (
    <>
      <HeroSection />
      <ProblemSection />
      <MechanismSection />
      <WhoSection />
      <WhatsInsideSection />
      <SocialProofSection />
      <PriceSection />
      <GuaranteeSection />
      <FAQSection />
      <FinalCTASection />

      {/* Sticky mobile CTA — appears after scrolling past hero */}
      <StickyBar href="#checkout" />
    </>
  )
}
