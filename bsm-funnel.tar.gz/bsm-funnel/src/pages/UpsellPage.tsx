import { Section } from '../components/layout/Section'
import { CTAButton } from '../components/ui/CTAButton'

export function UpsellPage() {
  return (
    <Section
      orbs={[
        { color: 'violet', position: 'top-[-10%] left-[-10%]', size: 'w-[500px] h-[500px]' },
        { color: 'mint', position: 'bottom-[-5%] right-[-10%]', size: 'w-[350px] h-[350px]' },
      ]}
      className="min-h-screen flex items-center"
    >
      <div className="text-center">
        <p className="text-rich-violet-400 text-xs md:text-sm font-semibold uppercase tracking-[0.2em] mb-6">
          Wait — Your Order Is Complete
        </p>

        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-8">
          Want Us to Set Up Your Campaign?
        </h1>

        <p className="max-w-2xl mx-auto text-gray-400 text-base md:text-lg leading-relaxed mb-10">
          You've got the system. Now let us build the campaign. Ad account structure, targeting, and your first set of signal-driven creatives — so you can launch with confidence this week.
        </p>

        <div className="flex flex-col items-center gap-4">
          <CTAButton
            text="Add to My Order"
            onClick={() => {
              // TODO: Stripe one-click charge via serverless function
            }}
          />
          <a
            href="/thank-you"
            className="text-gray-500 text-sm hover:text-gray-400 transition-colors"
          >
            No thanks, take me to my purchase →
          </a>
        </div>
      </div>
    </Section>
  )
}
