import { ReactNode } from 'react'
import { motion } from 'framer-motion'

interface SectionProps {
  children: ReactNode
  id?: string
  className?: string
  alt?: boolean
  orbs?: Array<{
    color: 'violet' | 'mint'
    position: string // Tailwind positioning classes
    size?: string    // Tailwind width/height classes
  }>
}

export function Section({ children, id, className = '', alt = false, orbs = [] }: SectionProps) {
  const bg = alt ? 'bg-section-alt' : 'bg-rich-black'

  return (
    <section
      id={id}
      className={`relative py-20 md:py-32 px-6 md:px-8 overflow-hidden ${bg} ${className}`}
    >
      {/* Ambient orbs */}
      {orbs.map((orb, i) => (
        <div
          key={i}
          className={`absolute pointer-events-none ${orb.position} ${orb.size || 'w-[400px] h-[400px]'}`}
          style={{
            background: orb.color === 'violet'
              ? 'radial-gradient(circle, rgba(124, 58, 237, 0.12), transparent 70%)'
              : 'radial-gradient(circle, rgba(16, 185, 129, 0.06), transparent 70%)',
            filter: orb.color === 'violet' ? 'blur(80px)' : 'blur(100px)',
          }}
        />
      ))}

      {/* Content */}
      <motion.div
        className="relative z-10 max-w-3xl mx-auto"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        viewport={{ once: true, margin: '-100px' }}
      >
        {children}
      </motion.div>
    </section>
  )
}

export function SectionWide({ children, id, className = '', alt = false, orbs = [] }: SectionProps) {
  const bg = alt ? 'bg-section-alt' : 'bg-rich-black'

  return (
    <section
      id={id}
      className={`relative py-20 md:py-32 px-6 md:px-8 overflow-hidden ${bg} ${className}`}
    >
      {orbs.map((orb, i) => (
        <div
          key={i}
          className={`absolute pointer-events-none ${orb.position} ${orb.size || 'w-[400px] h-[400px]'}`}
          style={{
            background: orb.color === 'violet'
              ? 'radial-gradient(circle, rgba(124, 58, 237, 0.12), transparent 70%)'
              : 'radial-gradient(circle, rgba(16, 185, 129, 0.06), transparent 70%)',
            filter: orb.color === 'violet' ? 'blur(80px)' : 'blur(100px)',
          }}
        />
      ))}

      <motion.div
        className="relative z-10 max-w-5xl mx-auto"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        viewport={{ once: true, margin: '-100px' }}
      >
        {children}
      </motion.div>
    </section>
  )
}
