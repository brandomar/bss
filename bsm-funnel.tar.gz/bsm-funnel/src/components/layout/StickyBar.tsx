import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

interface StickyBarProps {
  text?: string
  onClick?: () => void
  href?: string
}

export function StickyBar({ text = 'Get Instant Access — $27', onClick, href }: StickyBarProps) {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      // Show after scrolling past ~600px (past the hero CTA)
      setVisible(window.scrollY > 600)
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const handleClick = () => {
    if (href) {
      window.location.href = href
    } else if (onClick) {
      onClick()
    }
  }

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="fixed bottom-0 left-0 right-0 z-50 md:hidden"
        >
          <div className="bg-rich-black/95 backdrop-blur-md border-t border-white/[0.06] px-4 py-3 shadow-[0_-4px_30px_rgba(0,0,0,0.5)]">
            <button
              onClick={handleClick}
              className="
                w-full py-4 rounded-xl
                bg-gradient-to-br from-rich-violet-500 to-rich-violet-600
                text-white font-bold text-base
                shadow-[0_0_30px_rgba(124,58,237,0.3)]
                active:scale-[0.98] transition-transform
              "
            >
              {text}
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
