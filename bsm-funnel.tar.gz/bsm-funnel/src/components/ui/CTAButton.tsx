import { motion } from 'framer-motion'

interface CTAButtonProps {
  text: string
  subtext?: string
  onClick?: () => void
  href?: string
  className?: string
}

export function CTAButton({ text, subtext, onClick, href, className = '' }: CTAButtonProps) {
  const buttonContent = (
    <>
      <span className="relative z-10 text-lg font-bold tracking-wide">
        {text}
      </span>
      {subtext && (
        <span className="block mt-2 text-sm font-normal text-gray-300/70">
          {subtext}
        </span>
      )}
    </>
  )

  const buttonClasses = `
    cta-glow relative inline-flex flex-col items-center justify-center
    px-10 py-5 rounded-xl
    bg-gradient-to-br from-rich-violet-500 to-rich-violet-600
    text-white font-bold
    transition-all duration-300 ease-out
    hover:scale-[1.02] hover:shadow-[0_0_50px_rgba(124,58,237,0.45)]
    active:scale-[0.98]
    cursor-pointer w-full sm:w-auto
    ${className}
  `

  if (href) {
    return (
      <motion.a
        href={href}
        className={buttonClasses}
        whileTap={{ scale: 0.98 }}
      >
        {buttonContent}
      </motion.a>
    )
  }

  return (
    <motion.button
      onClick={onClick}
      className={buttonClasses}
      whileTap={{ scale: 0.98 }}
    >
      {buttonContent}
    </motion.button>
  )
}
