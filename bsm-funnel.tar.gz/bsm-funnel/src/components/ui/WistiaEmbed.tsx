import { useEffect, useRef, useState } from 'react'

interface WistiaEmbedProps {
  videoId?: string
  className?: string
}

export function WistiaEmbed({ videoId, className = '' }: WistiaEmbedProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    if (!videoId || loaded) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setLoaded(true)
          observer.disconnect()
        }
      },
      { rootMargin: '200px' }
    )

    if (containerRef.current) {
      observer.observe(containerRef.current)
    }

    return () => observer.disconnect()
  }, [videoId, loaded])

  useEffect(() => {
    if (!loaded || !videoId) return

    // Load Wistia scripts
    const script1 = document.createElement('script')
    script1.src = `https://fast.wistia.com/embed/medias/${videoId}.jsonp`
    script1.async = true
    document.head.appendChild(script1)

    const script2 = document.createElement('script')
    script2.src = 'https://fast.wistia.com/assets/external/E-v1.js'
    script2.async = true
    document.head.appendChild(script2)

    return () => {
      document.head.removeChild(script1)
      document.head.removeChild(script2)
    }
  }, [loaded, videoId])

  // Placeholder state when no video ID
  if (!videoId) {
    return (
      <div
        className={`relative w-full rounded-2xl overflow-hidden border border-white/[0.06] ${className}`}
        style={{ aspectRatio: '16/9' }}
      >
        <div className="absolute inset-0 bg-section-alt flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-rich-violet-500/20 flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-rich-violet-400 ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
            <p className="text-gray-500 text-sm">VSL Video — Coming Soon</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div
      ref={containerRef}
      className={`relative w-full rounded-2xl overflow-hidden border border-white/[0.06] shadow-[0_0_60px_rgba(0,0,0,0.5)] ${className}`}
      style={{ aspectRatio: '16/9' }}
    >
      {loaded ? (
        <div
          className={`wistia_embed wistia_async_${videoId} seo=true videoFoam=true`}
          style={{ width: '100%', height: '100%', position: 'relative' }}
        />
      ) : (
        <div className="absolute inset-0 bg-section-alt flex items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-rich-violet-500/20 flex items-center justify-center animate-pulse">
            <svg className="w-8 h-8 text-rich-violet-400 ml-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>
      )}
    </div>
  )
}
