import { Section } from '../layout/Section'

const bullets = [
  "You're spending $1,500+/month on Meta and getting leads — just not the right ones",
  'You have a proven offer that closes when the right person shows up',
  "You're tired of paying Meta to send you tire-kickers",
]

export function WhoSection() {
  return (
    <Section
      id="who"
      alt
      orbs={[
        { color: 'violet', position: 'bottom-[-10%] left-[-10%]', size: 'w-[350px] h-[350px]' },
      ]}
    >
      <div className="text-center">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-10">
          This Is For You If...
        </h2>
      </div>

      <div className="max-w-2xl mx-auto space-y-5 mb-10">
        {bullets.map((bullet, index) => (
          <div key={index} className="flex items-start gap-4">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-rich-violet-500/20 flex items-center justify-center mt-0.5">
              <span className="w-2 h-2 rounded-full bg-rich-violet-400" />
            </span>
            <p className="text-gray-300 text-base md:text-lg leading-relaxed">
              {bullet}
            </p>
          </div>
        ))}
      </div>

      <div className="glass-card p-6 md:p-8 max-w-2xl mx-auto text-center">
        <p className="text-gray-300 text-base md:text-lg leading-relaxed">
          <span className="text-white font-semibold">For agencies and freelancers:</span>{' '}
          better leads for your clients means longer retention, faster results, and more revenue from the same roster.
        </p>
      </div>
    </Section>
  )
}
