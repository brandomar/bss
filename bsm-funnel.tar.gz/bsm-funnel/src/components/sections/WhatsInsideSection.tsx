import { motion } from 'framer-motion'
import { Section } from '../layout/Section'

const phases = [
  {
    label: 'Capture Phase',
    items: [
      {
        name: 'The Gold Mine',
        description: 'Extract the exact language your buyers already use',
      },
    ],
  },
  {
    label: 'Amplify Phase',
    items: [
      {
        name: 'The Sentiment Extractor',
        description: 'Turn raw research into hooks and angles',
      },
      {
        name: 'The Filter Builder',
        description: 'Create self-selection hooks that repel bad fits',
      },
    ],
  },
  {
    label: 'Broadcast Phase',
    items: [
      {
        name: 'The Confirmation Engine',
        description: 'Pre-flight checklist + 72-hour validation framework',
      },
      {
        name: 'The Ad Congruence Score',
        description: 'Go/no-go decision before you spend',
      },
    ],
  },
]

export function WhatsInsideSection() {
  return (
    <Section
      id="whats-inside"
      orbs={[
        { color: 'violet', position: 'top-[10%] right-[-10%]', size: 'w-[400px] h-[400px]' },
        { color: 'mint', position: 'bottom-[-5%] left-[-10%]', size: 'w-[300px] h-[300px]' },
      ]}
    >
      <div className="text-center mb-14">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight">
          What's Inside
        </h2>
      </div>

      <div className="space-y-10">
        {phases.map((phase, phaseIndex) => (
          <motion.div
            key={phase.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: phaseIndex * 0.1 }}
            viewport={{ once: true, margin: '-50px' }}
          >
            <p className="text-rich-violet-400 text-xs font-semibold uppercase tracking-[0.2em] mb-4">
              {phase.label}
            </p>
            <div className="space-y-4">
              {phase.items.map((item) => (
                <div
                  key={item.name}
                  className="glass-card p-6 md:p-8 flex flex-col md:flex-row md:items-center gap-2 md:gap-4"
                >
                  <h3 className="text-white font-bold text-lg flex-shrink-0">
                    {item.name}
                  </h3>
                  <span className="hidden md:block text-gray-600">—</span>
                  <p className="text-gray-400 text-base">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        ))}

        {/* Bonus */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          viewport={{ once: true, margin: '-50px' }}
        >
          <p className="text-rich-mint-400 text-xs font-semibold uppercase tracking-[0.2em] mb-4">
            Bonus
          </p>
          <div className="glass-card p-6 md:p-8 border-rich-mint-500/20 flex flex-col md:flex-row md:items-center gap-2 md:gap-4">
            <h3 className="text-white font-bold text-lg flex-shrink-0">
              Video Walkthrough
            </h3>
            <span className="hidden md:block text-gray-600">—</span>
            <p className="text-gray-400 text-base">
              Watch the entire system run in under an hour
            </p>
          </div>
        </motion.div>
      </div>
    </Section>
  )
}
