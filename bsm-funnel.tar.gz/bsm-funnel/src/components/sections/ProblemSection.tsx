import { Section } from '../layout/Section'

export function ProblemSection() {
  return (
    <Section
      id="problem"
      alt
      orbs={[
        { color: 'violet', position: 'top-0 right-[-15%]', size: 'w-[350px] h-[350px]' },
      ]}
    >
      <div className="text-center">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-8">
          You're Getting Leads.
          <br />
          Just Not the Right Ones
        </h2>

        <div className="max-w-2xl mx-auto space-y-5 text-gray-400 text-base md:text-lg leading-relaxed">
          <p>
            You're spending real money on Meta. The leads are coming in.
          </p>
          <p>
            But your pipeline is packed with people who aren't serious,
            can't afford you, or were never going to buy in the first place.
          </p>
          <p>
            You're burning hours on calls that go nowhere.
            <br />
            Your pipeline looks full, but your revenue is flat.
          </p>
          <p>
            The problem isn't your offer. It's not your ad spend.{' '}
            <span className="text-white font-semibold">It's your signal.</span>
          </p>
          <p>
            Your ads are broadcasting on a frequency that attracts window shoppers.
          </p>
          <p>
            To fix this, you don't need to spend more — you need to get clear.
          </p>
        </div>
      </div>
    </Section>
  )
}
