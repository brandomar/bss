import { Section } from '../layout/Section'
import { CTAButton } from '../ui/CTAButton'

export function FinalCTASection() {
  return (
    <Section
      id="final-cta"
      alt
      orbs={[
        { color: 'violet', position: 'top-[-10%] left-[-10%]', size: 'w-[500px] h-[500px]' },
        { color: 'mint', position: 'bottom-[-10%] right-[-10%]', size: 'w-[350px] h-[350px]' },
      ]}
    >
      <div className="text-center">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6">
          Stop Paying for Bad Leads.
          <br />
          Start Broadcasting to Buyers
        </h2>

        <p className="max-w-2xl mx-auto text-gray-400 text-base md:text-lg leading-relaxed mb-10">
          The Buyer Signal Method gives you everything you need to launch ads that attract qualified clients — and repel everyone else.
        </p>

        <div className="flex flex-col items-center">
          <CTAButton
            text="Get Instant Access — $27"
            href="#checkout"
          />
          <p className="mt-4 text-sm text-gray-500">
            Instant delivery &bull; 30-day guarantee &bull; Implement in under an hour
          </p>
        </div>
      </div>
    </Section>
  )
}
