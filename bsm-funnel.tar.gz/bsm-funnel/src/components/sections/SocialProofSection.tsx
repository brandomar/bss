import { Section } from '../layout/Section'

export function SocialProofSection() {
  return (
    <Section
      id="social-proof"
      alt
      orbs={[
        { color: 'violet', position: 'top-[20%] left-[-15%]', size: 'w-[350px] h-[350px]' },
      ]}
    >
      <div className="text-center">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-8">
          Why This Works
        </h2>

        <div className="max-w-2xl mx-auto space-y-5 text-gray-400 text-base md:text-lg leading-relaxed mb-14">
          <p>
            Meta's algorithm functions like real-time SEO. When your ad copy uses the exact language your ideal buyer already uses, Meta rewards you with cheaper traffic and better placements.
          </p>
          <p>
            This system writes ads based on what your market has already told you works — you just have to know where to look.
          </p>
        </div>

        {/* Testimonial placeholders */}
        <div className="space-y-6 max-w-2xl mx-auto">
          <div className="glass-card p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-section-alt-2 mx-auto mb-4 flex items-center justify-center">
              <svg className="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-gray-500 text-sm">Video testimonial — coming soon</p>
          </div>

          <div className="glass-card p-8 text-center">
            <div className="text-gray-600 text-4xl mb-4">"</div>
            <p className="text-gray-500 text-sm italic">Quote with name and result — coming soon</p>
          </div>
        </div>
      </div>
    </Section>
  )
}
