import { Section } from '../layout/Section'
import { CTAButton } from '../ui/CTAButton'

export function PriceSection() {
  return (
    <Section
      id="price"
      orbs={[
        { color: 'violet', position: 'top-[-5%] right-[-10%]', size: 'w-[400px] h-[400px]' },
        { color: 'mint', position: 'bottom-[-10%] left-[-5%]', size: 'w-[250px] h-[250px]' },
      ]}
    >
      <div className="text-center">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-8">
          Get the Entire System for $27
        </h2>

        <div className="max-w-2xl mx-auto space-y-5 text-gray-400 text-base md:text-lg leading-relaxed mb-10">
          <p>
            You could hire an agency for $3,000–$10,000/month.
          </p>
          <p>
            You could spend months learning copywriting.
          </p>
          <p>
            Or you could use a system that tells you exactly what to say, how to filter, and when to scale — for less than the cost of two bad leads.
          </p>
        </div>

        <div className="flex flex-col items-center">
          <CTAButton
            text="Get Instant Access — $27"
            href="#checkout"
          />
          <p className="mt-4 text-sm text-gray-500">
            One-time payment &bull; Instant access &bull; 30-day guarantee
          </p>
        </div>
      </div>
    </Section>
  )
}
