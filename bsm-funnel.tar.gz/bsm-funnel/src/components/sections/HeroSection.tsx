import { motion } from 'framer-motion'
import { CTAButton } from '../ui/CTAButton'
import { WistiaEmbed } from '../ui/WistiaEmbed'

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-6 md:px-8 pt-16 pb-20 md:pt-24 md:pb-32 overflow-hidden bg-rich-black">
      {/* Ambient orbs */}
      <div
        className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(124, 58, 237, 0.12), transparent 70%)',
          filter: 'blur(80px)',
        }}
      />
      <div
        className="absolute bottom-[-5%] right-[-5%] w-[400px] h-[400px] pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.06), transparent 70%)',
          filter: 'blur(100px)',
        }}
      />

      <div className="relative z-10 max-w-3xl mx-auto text-center">
        {/* Eyebrow */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-rich-violet-400 text-xs md:text-sm font-semibold uppercase tracking-[0.2em] mb-6 md:mb-8"
        >
          For Coaches, Consultants, Freelancers & Agencies Spending $1,500+/mo on Meta
        </motion.p>

        {/* Main headline */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.1] mb-6 md:mb-8"
        >
          What If You Could Disqualify{' '}
          <span
            className="inline-block"
            style={{
              background: 'linear-gradient(135deg, #7C3AED, #A78BFA, #10B981)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Bad Leads Before They Click
          </span>
          ?
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-lg md:text-xl text-gray-300 leading-relaxed mb-10 md:mb-14 max-w-2xl mx-auto"
        >
          A three-step system that captures ideal client language, filters out the wrong people, and broadcasts ads that convert.
        </motion.p>

        {/* VSL */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mb-10 md:mb-14"
        >
          <WistiaEmbed />
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex flex-col items-center"
        >
          <CTAButton
            text="Get Instant Access — $27"
            href="#checkout"
          />
          <p className="mt-4 text-sm text-gray-500">
            Instant access &bull; No subscription &bull; 30-day guarantee
          </p>
        </motion.div>
      </div>
    </section>
  )
}
