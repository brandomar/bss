import { motion } from 'framer-motion'
import { SectionWide } from '../layout/Section'

const steps = [
  {
    number: '01',
    name: 'Capture',
    description:
      "The system shows you exactly where your ideal buyers are already talking and extracts the raw language they use when no one's selling to them. You're not inventing hooks. You're capturing them.",
  },
  {
    number: '02',
    name: 'Amplify',
    description:
      "The system turns that raw language into hooks and ad angles with built-in filters. The wrong people read your ad and think 'that's not me.' They scroll past. They never click. They never waste your time.",
  },
  {
    number: '03',
    name: 'Broadcast',
    description:
      "You launch with a pre-flight checklist and a clear green light or red light before you spend a dollar. You'll know within 72 hours whether to scale, tune, or pivot.",
  },
]

export function MechanismSection() {
  return (
    <SectionWide
      id="mechanism"
      orbs={[
        { color: 'violet', position: 'top-[20%] left-[-10%]', size: 'w-[450px] h-[450px]' },
        { color: 'mint', position: 'bottom-[-10%] right-[-5%]', size: 'w-[300px] h-[300px]' },
      ]}
    >
      <div className="text-center mb-14 md:mb-20">
        <p className="text-rich-violet-400 text-xs md:text-sm font-semibold uppercase tracking-[0.2em] mb-4">
          Introducing
        </p>
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6">
          The Buyer Signal Method
        </h2>
        <p className="text-gray-400 text-base md:text-lg max-w-xl mx-auto">
          A three-step system that transforms your ad creation process from guesswork into a data-driven confirmation process.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
        {steps.map((step, index) => (
          <motion.div
            key={step.number}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            viewport={{ once: true, margin: '-50px' }}
            className="glass-card p-8 md:p-10 relative group"
          >
            {/* Left accent border */}
            <div className="absolute left-0 top-8 bottom-8 w-[3px] rounded-full bg-gradient-to-b from-rich-violet-500 to-rich-violet-700 opacity-60 group-hover:opacity-100 transition-opacity" />

            <p className="text-rich-violet-400 text-xs font-semibold uppercase tracking-[0.2em] mb-3 pl-4">
              Step {step.number}
            </p>
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4 pl-4">
              {step.name}
            </h3>
            <p className="text-gray-400 text-base leading-relaxed pl-4">
              {step.description}
            </p>
          </motion.div>
        ))}
      </div>
    </SectionWide>
  )
}
