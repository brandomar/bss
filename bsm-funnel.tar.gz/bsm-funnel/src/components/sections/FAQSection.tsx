import { Section } from '../layout/Section'
import { FAQAccordion } from '../ui/FAQAccordion'

const faqItems = [
  {
    question: 'How fast can I implement this?',
    answer:
      'Under an hour for the complete system. Most people have their first set of signal-driven ad copy ready the same day.',
  },
  {
    question: 'Will this work for my niche?',
    answer:
      "Yes. The methodology works for any niche where your buyers talk about their problems online — which is virtually every niche. Agencies use this across client verticals.",
  },
  {
    question: 'Is there a guarantee?',
    answer:
      "Yes. 30-day money-back guarantee. If you don't feel clearer and more confident about your ad messaging, email for a full refund.",
  },
]

export function FAQSection() {
  return (
    <Section
      id="faq"
      orbs={[
        { color: 'violet', position: 'top-[30%] right-[-15%]', size: 'w-[300px] h-[300px]' },
      ]}
    >
      <div className="text-center mb-10">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight">
          Questions
        </h2>
      </div>

      <div className="max-w-2xl mx-auto">
        <FAQAccordion items={faqItems} />
      </div>
    </Section>
  )
}
